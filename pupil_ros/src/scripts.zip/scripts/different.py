#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
from darknet_ros_msgs.msg import BoundingBoxes
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from datetime import datetime, timedelta

class ObjectSearchNode:
    def __init__(self):
        rospy.init_node("object_search_node")

        self.fixated_label = None
        self.searching = False
        self.image = None
        self.bridge = CvBridge()
        self.search_start_time = None
        self.timeout_seconds = 10
        self.post_search_timeout = rospy.get_param("~post_search_timeout", 5)  # seconds cooldown after search

        self.fixation_crop = None
        self.last_search_end_time = None  # To track cooldown period after search finishes

        self.match_threshold = rospy.get_param("~match_threshold", 0.5)

        rospy.Subscriber("/fixated_object", String, self.fixation_callback)
        rospy.Subscriber("/hsr/darknet_ros/bounding_boxes", BoundingBoxes, self.bbox_callback)
        rospy.Subscriber("/hsr/darknet_ros/detection_image", Image, self.image_callback)

        self.image_pub = rospy.Publisher("/hsr/found_object_image", Image, queue_size=10)

        rospy.loginfo("Object search node initialized and waiting for fixation...")

    def fixation_callback(self, msg):
        now = datetime.now()
        # Check if currently searching or still in cooldown period after last search
        if self.searching:
            rospy.loginfo("Currently searching. Ignoring new fixation until search completes or times out.")
            return
        if self.last_search_end_time and (now - self.last_search_end_time).total_seconds() < self.post_search_timeout:
            rospy.loginfo(f"In cooldown after last search. Ignoring fixation for {self.post_search_timeout} seconds.")
            return

        self.fixated_label = msg.data
        self.searching = True
        self.search_start_time = now
        rospy.loginfo(f"Received target object to find: {self.fixated_label}")

    def image_callback(self, msg):
        try:
            self.image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            rospy.logwarn(f"Failed to convert image: {e}")

    def compute_orb_score(self, query_img, candidate_img):
        orb = cv2.ORB_create()
        kp1, des1 = orb.detectAndCompute(query_img, None)
        kp2, des2 = orb.detectAndCompute(candidate_img, None)

        if des1 is None or des2 is None:
            return 0

        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
        matches = bf.match(des1, des2)

        if not matches:
            return 0

        matches = sorted(matches, key=lambda x: x.distance)
        distances = [m.distance for m in matches]
        score = 1 / (np.mean(distances) + 1e-6)
        return score

    def compute_color_score(self, query_img, candidate_img):
        query_hsv = cv2.cvtColor(query_img, cv2.COLOR_BGR2HSV)
        candidate_hsv = cv2.cvtColor(candidate_img, cv2.COLOR_BGR2HSV)

        hist_q = cv2.calcHist([query_hsv], [0, 1, 2], None, [8, 8, 8], [0, 180, 0, 256, 0, 256])
        hist_c = cv2.calcHist([candidate_hsv], [0, 1, 2], None, [8, 8, 8], [0, 180, 0, 256, 0, 256])

        cv2.normalize(hist_q, hist_q)
        cv2.normalize(hist_c, hist_c)

        score = cv2.compareHist(hist_q, hist_c, cv2.HISTCMP_CORREL)
        return score

    def match_objects(self, query_img, candidates):
        best_score = -float('inf')
        best_idx = -1
        alpha = 0.5
        beta = 0.5

        for idx, candidate in enumerate(candidates):
            orb_score = self.compute_orb_score(query_img, candidate)
            color_score = self.compute_color_score(query_img, candidate)
            color_score = (color_score + 1) / 2  # normalize color score to 0-1

            final_score = alpha * orb_score + beta * color_score
            rospy.loginfo(f"[{idx}] ORB: {orb_score:.2f}, Color: {color_score:.2f}, Final: {final_score:.2f}")

            if final_score > best_score:
                best_score = final_score
                best_idx = idx

        return best_idx, best_score

    def bbox_callback(self, msg):
        if not self.searching or self.fixated_label is None or self.image is None:
            return

        if datetime.now() - self.search_start_time > timedelta(seconds=self.timeout_seconds):
            rospy.loginfo(f"Timeout: Could not find '{self.fixated_label}' in {self.timeout_seconds} seconds.")
            self.searching = False
            self.fixated_label = None
            self.last_search_end_time = datetime.now()
            return

        candidates = []
        boxes = []

        for box in msg.bounding_boxes:
            if box.Class == self.fixated_label:
                cropped = self.image[box.ymin:box.ymax, box.xmin:box.xmax]
                if cropped.size > 0:
                    candidates.append(cropped)
                    boxes.append(box)

        if not candidates:
            return

        if self.fixation_crop is None:
            # Fallback: use center crop of the image for testing/demo
            h, w, _ = self.image.shape
            ch, cw = h // 2, w // 2
            self.fixation_crop = self.image[ch-50:ch+50, cw-50:cw+50]
            rospy.logwarn("No fixation crop set; using center crop as dummy query.")

        best_idx, score = self.match_objects(self.fixation_crop, candidates)

        if best_idx != -1:
            best_box = boxes[best_idx]
            if score > self.match_threshold:
                rospy.loginfo(f"Object '{best_box.Class}' FOUND by HSR via matching! Score: {score:.2f}")

                cv2.rectangle(
                    self.image,
                    (best_box.xmin, best_box.ymin),
                    (best_box.xmax, best_box.ymax),
                    (0, 255, 0), 2
                )
                cv2.putText(
                    self.image,
                    best_box.Class,
                    (best_box.xmin, best_box.ymin - 10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.9,
                    (0, 255, 0),
                    2
                )

                result_img = self.bridge.cv2_to_imgmsg(self.image, encoding="bgr8")
                self.image_pub.publish(result_img)

                self.searching = False
                self.fixated_label = None
                self.fixation_crop = None
                self.last_search_end_time = datetime.now()
                rospy.loginfo("Search complete. Ready for next fixation.")

            else:
                rospy.loginfo(f"Its a similar object just not the exact. Score: {score:.2f}, threshold: {self.match_threshold}")
                # Still end search and cooldown to avoid spamming
                self.searching = False
                self.fixated_label = None
                self.fixation_crop = None
                self.last_search_end_time = datetime.now()
        else:
            rospy.loginfo("No candidates matched at all yet.")

    def run(self):
        rospy.spin()

if __name__ == "__main__":
    try:
        node = ObjectSearchNode()
        node.run()
    except rospy.ROSInterruptException:
        pass

