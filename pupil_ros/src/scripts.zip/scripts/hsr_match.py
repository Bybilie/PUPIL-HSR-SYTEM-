import rospy
from std_msgs.msg import String
from darknet_ros_msgs.msg import BoundingBoxes
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
from datetime import datetime, timedelta
import torch
import torchvision.transforms as transforms
from torchvision.models import resnet50
import torch.nn.functional as F


class ObjectSearchNode:
    def __init__(self):
        rospy.init_node("object_search_node")

        self.fixated_label = None
        self.searching = False
        self.image = None
        self.bridge = CvBridge()
        self.search_start_time = None
        self.timeout_seconds = 10
        self.post_search_timeout = rospy.get_param("~post_search_timeout", 5)

        self.fixation_crop = None
        self.last_search_end_time = None
        self.match_threshold = rospy.get_param("~match_threshold", 0.8)  # for cosine similarity

        # ResNet Model
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = resnet50(pretrained=True)
        self.model.eval().to(self.device)
        self.preprocess = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                 std=[0.229, 0.224, 0.225]),
        ])

        rospy.Subscriber("/fixated_object", String, self.fixation_callback)
        rospy.Subscriber("/hsr/darknet_ros/bounding_boxes", BoundingBoxes, self.bbox_callback)
        rospy.Subscriber("/hsr/darknet_ros/detection_image", Image, self.image_callback)

        self.image_pub = rospy.Publisher("/hsr/found_object_image", Image, queue_size=10)

        rospy.loginfo("Object search node initialized with ResNet-based matching.")

    def fixation_callback(self, msg):
        now = datetime.now()
        if self.searching:
            rospy.loginfo("Currently searching. Ignoring new fixation.")
            return
        if self.last_search_end_time and (now - self.last_search_end_time).total_seconds() < self.post_search_timeout:
            rospy.loginfo("Cooldown in progress. Ignoring new fixation.")
            return

        self.fixated_label = msg.data
        self.searching = True
        self.search_start_time = now
        rospy.loginfo(f"Received target: {self.fixated_label}")

    def image_callback(self, msg):
        try:
            self.image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            rospy.logwarn(f"Image conversion failed: {e}")

    def get_resnet_embedding(self, img):
        try:
            input_tensor = self.preprocess(img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                features = self.model(input_tensor)
            return F.normalize(features, p=2, dim=1).cpu().numpy().flatten()
        except Exception as e:
            rospy.logwarn(f"Failed to get embedding: {e}")
            return None

    def cosine_similarity(self, vec1, vec2):
        return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2) + 1e-6)

    def match_objects(self, query_embed, candidate_embeds):
        best_score = -1
        best_idx = -1

        for i, embed in enumerate(candidate_embeds):
            score = self.cosine_similarity(query_embed, embed)
            rospy.loginfo(f"[{i}] Cosine similarity: {score:.3f}")
            if score > best_score:
                best_score = score
                best_idx = i

        return best_idx, best_score

    def bbox_callback(self, msg):
        if not self.searching or self.fixated_label is None or self.image is None:
            return

        if datetime.now() - self.search_start_time > timedelta(seconds=self.timeout_seconds):
            rospy.loginfo(f"Timeout: Could not find '{self.fixated_label}' in {self.timeout_seconds} seconds.")
            self.searching = False
            self.fixated_label = None
            self.last_search_end_time = datetime.now()
            return

        candidates = []
        boxes = []

        for box in msg.bounding_boxes:
            if box.Class == self.fixated_label:
                cropped = self.image[box.ymin:box.ymax, box.xmin:box.xmax]
                if cropped.size > 0:
                    embedding = self.get_resnet_embedding(cropped)
                    if embedding is not None:
                        candidates.append(embedding)
                        boxes.append(box)

        if not candidates:
            return

        if self.fixation_crop is None:
            # fallback for testing
            h, w, _ = self.image.shape
            ch, cw = h // 2, w // 2
            self.fixation_crop = self.image[ch - 50:ch + 50, cw - 50:cw + 50]
            rospy.logwarn("No fixation crop provided. Using center crop as dummy.")

        query_embedding = self.get_resnet_embedding(self.fixation_crop)
        if query_embedding is None:
            rospy.logwarn("Failed to compute query embedding. Aborting search.")
            self.searching = False
            self.fixated_label = None
            return

        best_idx, score = self.match_objects(query_embedding, candidates)

        if best_idx != -1 and score > self.match_threshold:
            best_box = boxes[best_idx]
            rospy.loginfo(f"Object '{best_box.Class}' FOUND! Score: {score:.3f}")

            cv2.rectangle(self.image, (best_box.xmin, best_box.ymin), (best_box.xmax, best_box.ymax), (0, 255, 0), 2)
            cv2.putText(self.image, best_box.Class, (best_box.xmin, best_box.ymin - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

            result_img = self.bridge.cv2_to_imgmsg(self.image, encoding="bgr8")
            self.image_pub.publish(result_img)

            self.searching = False
            self.fixated_label = None
            self.fixation_crop = None
            self.last_search_end_time = datetime.now()
        else:
            rospy.loginfo(f"No good match. Best score: {score:.3f}, threshold: {self.match_threshold}")
            self.searching = False
            self.fixated_label = None
            self.fixation_crop = None
            self.last_search_end_time = datetime.now()

    def run(self):
        rospy.spin()


if __name__ == "__main__":
    try:
        node = ObjectSearchNode()
        node.run()
    except rospy.ROSInterruptException:
        pass

