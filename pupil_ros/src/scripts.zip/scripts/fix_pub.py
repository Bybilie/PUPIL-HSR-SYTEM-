#!/usr/bin/env python
import rospy
import csv
import os
from std_msgs.msg import String
from darknet_ros_msgs.msg import BoundingBoxes

log_file = os.path.expanduser("~/fixation_detection_analysis.csv")
fieldnames = ["fixation_time", "fixated_object", "detection_time", "detected_object", "confidence", "match", "delay"]

# State
current_fixation = None
fixation_time = None
detection_logged = False

# Setup CSV if not present
if not os.path.exists(log_file):
    with open(log_file, 'w') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

def log_miss():
    if current_fixation and not detection_logged:
        with open(log_file, 'a') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writerow({
                "fixation_time": fixation_time,
                "fixated_object": current_fixation,
                "match": False
            })
        rospy.logwarn(f"[MISS] No object matched fixation '{current_fixation}'")

def fixation_callback(msg):
    global current_fixation, fixation_time, detection_logged
    log_miss()  # Log previous round (if needed)

    current_fixation = msg.data.lower()
    fixation_time = rospy.Time.now().to_sec()
    detection_logged = False
    rospy.loginfo(f"[FIXATION] '{current_fixation}' at {fixation_time:.2f}")

def detection_callback(msg):
    global detection_logged

    if current_fixation is None:
        return

    detection_time = rospy.Time.now().to_sec()
    delay = detection_time - fixation_time

    for box in msg.bounding_boxes:
        detected_label = box.Class.lower()
        confidence = box.probability
        match = current_fixation in detected_label

        with open(log_file, 'a') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writerow({
                "fixation_time": fixation_time,
                "fixated_object": current_fixation,
                "detection_time": detection_time,
                "detected_object": detected_label,
                "confidence": round(confidence, 4),
                "match": match,
                "delay": round(delay, 3)
            })

        if match:
            detection_logged = True
            rospy.loginfo(f"[MATCH] Fixated '{current_fixation}' matched '{detected_label}' ({confidence:.2f})")

def main():
    rospy.init_node('fixation_logger_ctrl_c')
    rospy.Subscriber("/fixated_object", String, fixation_callback)
    rospy.Subscriber("/hsr/darknet_ros/bounding_boxes", BoundingBoxes, detection_callback)
    rospy.loginfo("Fixation logger running. Restart your object search node each round. Press Ctrl+C when done.")
    rospy.spin()
    log_miss()  # Final check on shutdown

if __name__ == "__main__":
    main()

